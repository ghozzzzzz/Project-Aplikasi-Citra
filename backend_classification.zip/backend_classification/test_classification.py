import os
import cv2
import numpy as np
import pickle
#from FeatureExtractor_GLCM import GLCMFeatureExtractor
from skimage.feature import hog
from skimage import exposure
from sklearn.naive_bayes import GaussianNB
import sys

# Sesuaikan path tempat Anda menyimpan test_classification.py
current_folder = os.path.dirname(__file__)
sys.path.append(current_folder)

class ImageClassifierTester:
    def __init__(self, model_dir, feature_dir, feature_type):
        self.model_dir = model_dir
        self.feature_dir = feature_dir
        self.feature_type = feature_type
        self.data = None
        self.labels = None
        self.classifier = None
        self.feature_extractors = {
            "histogram": self.extract_histogram,
            "glcm": self.extract_glcm,
            "hog": self.extract_hog
        }

    def extract_histogram(self, image):
        hist = cv2.calcHist([image], [0, 1, 2], None, [8, 8, 8], [0, 256, 0, 256, 0, 256])
        cv2.normalize(hist, hist)
        hist = hist.flatten()
        hist = hist.reshape(1, -1)
        return hist

    def extract_glcm(self, image):
        feature_extractor = GLCMFeatureExtractor()
        glcm_features = feature_extractor.compute_glcm_features(image)
        return glcm_features.flatten()

    def extract_hog(self, image):
        resized_image = cv2.resize(image, (64, 64))
        hog_features = []
        for channel in range(resized_image.shape[2]):
            features, _ = hog(resized_image[:, :, channel], orientations=8, pixels_per_cell=(8, 8),
                              cells_per_block=(1, 1), visualize=True)
            features = exposure.rescale_intensity(features, in_range=(0, 10))
            features = features.flatten()
            hog_features.extend(features)
        hog_features = np.array(hog_features).reshape(1, -1)
        return hog_features

    def load_data(self):
        self.data = np.load(os.path.join(self.feature_dir, 'data.npy'))
        self.labels = np.load(os.path.join(self.feature_dir, 'labels.npy'))

    def load_classifier(self, classifier_type):
        model_file = os.path.join(self.model_dir, f'{classifier_type}_model.pkl')
        with open(model_file, 'rb') as f:
            self.classifier = pickle.load(f)

    def read_image(self, test_image_path):
        image = cv2.imread(test_image_path)
        return image

    def process_image(self, image):
        return image

    def test_classifier(self, test_image_path):
        image = self.read_image(test_image_path)
        image = self.process_image(image)
        features = self.feature_extractors[self.feature_type](image)

        if isinstance(self.classifier, GaussianNB):
            features = features.reshape(1, -1)

        prediction = self.classifier.predict(features)
        return prediction[0], features, image


if __name__ == "__main__":
    DATASET_DIR = os.path.join(current_folder, 'dataset/nyobanyoba')
    MODEL_DIR = os.path.join(current_folder, 'model') #model klasifikasi
    FEATURE_DIR = os.path.join(current_folder, 'fitur') 
    FEATURE_TYPE = 'hog'  # choose from 'histogram', 'glcm', or 'hog'
    CLASSIFIER_TYPE = "naive_bayes" # "mlp", "naive_bayes"
    TEST_IMAGE_PATH = os.path.join(current_folder, 'dataset/nyobanyoba/Garpu/Garpu001.jpg')

    tester = ImageClassifierTester(MODEL_DIR, FEATURE_DIR, FEATURE_TYPE)

    try:
        tester.load_data()
        tester.load_classifier(CLASSIFIER_TYPE)
        prediction = tester.test_classifier(TEST_IMAGE_PATH)
        print("Prediction:", prediction)
    except FileNotFoundError as e:
        print(f"Error: {e}. Please check the availability of the file and directory.")
    except Exception as e:
        print("Error during classification:", str(e))
